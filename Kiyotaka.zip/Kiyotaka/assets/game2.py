import pygame
import sys
import os
import random
from pygame.math import Vector2

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Screen setup
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

bg_x = 0  # Initialize bg_x properly
pygame.display.set_caption("Side-Scroller Combat")

# Game states
MENU = 0
PLAYING = 1
GAME_OVER = 2
VICTORY = 3
game_state = MENU

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Game clock
clock = pygame.time.Clock()
FPS = 60

# Physics
GRAVITY = 0.5
JUMP_STRENGTH = -12
PLAYER_SPEED = 5
GROUND_LEVEL = SCREEN_HEIGHT - 50

# Level settings
LEVEL_WIDTH = 3000  # Total playable area width
MAX_ENEMIES = 10    # Enemies to defeat to win

# Load assets
def load_spritesheet(path, frame_width, frame_height, frame_count, scale=1):
    full_path = f'assets/{path}'
    if not os.path.exists(full_path):
        raise FileNotFoundError(f"Sprite sheet not found: {full_path}")
    sheet = pygame.image.load(full_path).convert_alpha()
    frames = []
    for i in range(frame_count):
        frame = sheet.subsurface(pygame.Rect(i * frame_width, 0, frame_width, frame_height))
        if scale != 1:
            frame = pygame.transform.scale(frame, (int(frame_width * scale), int(frame_height * scale)))
        frames.append(frame)
    return frames

def load_sound(path):
    return pygame.mixer.Sound(f'assets/sounds/{path}')

# Load sounds
SOUNDS = {
    'jump': load_sound('jump.wav'),
    'shoot': load_sound('shoot.wav'),
    'hit': load_sound('hit.wav'),
    'death': load_sound('death.wav')
}

# Load UI
heart_full = pygame.image.load('assets/ui/heart_full.png').convert_alpha()
heart_empty = pygame.image.load('assets/ui/heart_empty.png').convert_alpha()

# Load background (original size, won't be stretched)
background_orig = pygame.image.load('assets/background.png').convert()
bg_width, bg_height = background_orig.get_size()

# Animation class
class Animation:
    def __init__(self, frames, fps=10, loop=True):
        self.frames = frames
        self.fps = fps
        self.loop = loop
        self.frame_index = 0
        self.accumulated_time = 0
        self.done = False

    def update(self, dt):
        if self.fps <= 0: return
        self.accumulated_time += dt
        if self.accumulated_time >= 1.0 / self.fps:
            self.accumulated_time = 0
            self.frame_index += 1
            if self.frame_index >= len(self.frames):
                if self.loop: 
                    self.frame_index = 0
                else:
                    self.frame_index = len(self.frames) - 1
                    self.done = True

    def get_frame(self, flipped=False):
        frame = self.frames[int(self.frame_index)]
        return pygame.transform.flip(frame, flipped, False) if flipped else frame

# Entity class
class Entity(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.vel = Vector2(0, 0)
        self.facing_right = True
        self.state = "idle"
        self.animations = {}
        self.current_animation = None
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.health = 5
        self.max_health = 5
        self.invincible = 0

    def load_animations(self, idle_frames, run_frames, attack_frames):
        self.animations = {
            "idle": Animation(idle_frames, fps=8),
            "run": Animation(run_frames, fps=12),
            "attack": Animation(attack_frames, fps=15, loop=False)
        }
        self.current_animation = self.animations["idle"]

    def update_animation(self, dt):
        if self.state in self.animations:
            if self.current_animation != self.animations[self.state]:
                self.current_animation = self.animations[self.state]
                self.current_animation.reset()
        
        self.current_animation.update(dt)
        self.image = self.current_animation.get_frame(not self.facing_right)
        
        if self.invincible > 0:
            if self.invincible % 10 < 5:
                self.image.fill((255, 255, 255, 128), special_flags=pygame.BLEND_RGBA_MULT)
            self.invincible -= 1

    def take_damage(self, amount):
        if self.invincible <= 0:
            self.health -= amount
            self.invincible = 30
            return True
        return False

# Player class
class Player(Entity):
    def __init__(self, x, y):
        super().__init__(x, y, 40, 60)
        self.speed = PLAYER_SPEED
        self.jump_power = JUMP_STRENGTH
        self.is_jumping = False
        self.bullets = []
        self.attack_cooldown = 0
        
        # Load animations
        idle_frames = load_spritesheet("player/idle.png", 64, 64, 4, 1.5)
        run_frames = load_spritesheet("player/run.png", 64, 64, 6, 1.5)
        attack_frames = load_spritesheet("player/attack.png", 64, 64, 4, 1.5)
        self.load_animations(idle_frames, run_frames, attack_frames)

    def update(self, dt):
        # Physics
        self.vel.y += GRAVITY
        self.rect.x += self.vel.x
        self.rect.y += self.vel.y
        
        # Ground collision
        if self.rect.bottom >= GROUND_LEVEL:
            self.rect.bottom = GROUND_LEVEL
            self.vel.y = 0
            self.is_jumping = False
        
        # State management
        new_state = "idle"
        if self.state == "attack" and not self.current_animation.done:
            new_state = "attack"
        elif abs(self.vel.x) > 0.5:
            new_state = "run"
        
        self.state = new_state
        self.update_animation(dt)
        
        # Cooldowns
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

    def jump(self):
        if not self.is_jumping:
            self.vel.y = self.jump_power
            self.is_jumping = True
            SOUNDS['jump'].play()

    def shoot(self):
        if self.attack_cooldown == 0:
            self.state = "attack"
            self.attack_cooldown = 20
            SOUNDS['shoot'].play()
            
            # Create bullet
            bullet = {
                "rect": pygame.Rect(
                    self.rect.right if self.facing_right else self.rect.left - 20,
                    self.rect.centery - 5,
                    20,
                    10
                ),
                "direction": 1 if self.facing_right else -1,
                "speed": 10
            }
            self.bullets.append(bullet)

# Enemy class
class Enemy(Entity):
    def __init__(self, x, y):
        super().__init__(x, y, 40, 40)
        self.speed = 1.5
        self.attack_cooldown = 0
        
        # Load animations
        idle_frames = load_spritesheet("enemy/idle.png", 64, 64, 4, 1.5)
        run_frames = load_spritesheet("enemy/run.png", 64, 64, 6, 1.5)
        attack_frames = load_spritesheet("enemy/attack.png", 64, 64, 4, 1.5)
        self.load_animations(idle_frames, run_frames, attack_frames)

    def update(self, player, dt):
        # AI behavior
        dx = player.rect.centerx - self.rect.centerx
        distance = abs(dx)
        
        # Face player
        self.facing_right = dx > 0
        
        # State machine
        if distance < 50:  # Attack range
            self.state = "attack"
            self.vel.x = 0
            
            if self.current_animation.done and self.attack_cooldown == 0:
                if self.rect.colliderect(player.rect):
                    player.take_damage(1)
                    SOUNDS['hit'].play()
                self.attack_cooldown = 60
        elif distance < 300:  # Detection range
            self.state = "run"
            self.vel.x = (1 if dx > 0 else -1) * self.speed
        else:
            self.state = "idle"
            self.vel.x = 0
        
        # Movement
        self.rect.x += self.vel.x
        self.rect.y = GROUND_LEVEL - self.rect.height
        
        # Update animation
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        self.update_animation(dt)

# Camera class
class Camera:
    def __init__(self, target, level_width):
        self.target = target
        self.level_width = level_width
        self.offset = Vector2(0, 0)
    
    def update(self):
        target_x = -self.target.rect.centerx + SCREEN_WIDTH // 2
        target_x = min(0, target_x)  # Left boundary
        target_x = max(-(self.level_width - SCREEN_WIDTH), target_x)  # Right boundary
        self.offset.x = target_x

# Health display
class HealthDisplay:
    def __init__(self, player):
        self.player = player
        self.full_heart = heart_full
        self.empty_heart = heart_empty
    
    def draw(self, surface):
        for i in range(self.player.max_health):
            pos = (10 + i * (self.full_heart.get_width() + 5), 10)
            # Draw hearts based on player's health
            surface.blit(self.full_heart if i < self.player.health else self.empty_heart, pos)

# Game initialization
def init_game():
    global player, all_sprites, enemies, camera, health_display, enemy_count
    
    # Create groups
    all_sprites = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    
    # Create player
    player = Player(100, GROUND_LEVEL - 60)
    all_sprites.add(player)
    health_display = HealthDisplay(player)
    
    # Create camera
    camera = Camera(player, LEVEL_WIDTH)
    
    # Create enemies
    enemy_count = MAX_ENEMIES
    for i in range(min(3, MAX_ENEMIES)):  # Start with 3 enemies
        x = random.randint(500, LEVEL_WIDTH - 100)
        enemy = Enemy(x, GROUND_LEVEL - 40)
        enemies.add(enemy)
        all_sprites.add(enemy)

# Initialize game
init_game()
running = True

while running:
    dt = clock.tick(FPS) / 1000.0
    
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_RETURN and game_state != PLAYING:
                init_game()
                game_state = PLAYING
            elif game_state == PLAYING:
                if event.key == pygame.K_w:
                    player.jump()
                elif event.key == pygame.K_SPACE:
                    player.shoot()
    
    # Game logic
    if game_state == PLAYING:
        # Player movement
        keys = pygame.key.get_pressed()
        player.vel.x = (keys[pygame.K_d] - keys[pygame.K_a]) * player.speed
        
        # Update objects
        player.update(dt)
        camera.update()
        
        # Spawn enemies
        if len(enemies) < enemy_count and random.random() < 0.02:
            x = camera.offset.x + SCREEN_WIDTH + random.randint(100, 300)
            if x < LEVEL_WIDTH - 100:
                enemy = Enemy(x, GROUND_LEVEL - 40)
                enemies.add(enemy)
                all_sprites.add(enemy)
        
        # Update enemies
        for enemy in list(enemies):
            enemy.update(player, dt)
            if enemy.health <= 0:
                SOUNDS['death'].play()
                enemies.remove(enemy)
                all_sprites.remove(enemy)
        
        # Update bullets
        for bullet in list(player.bullets):
            bullet["rect"].x += bullet["direction"] * bullet["speed"]
            
            # Remove if off-screen
            if bullet["rect"].right < 0 or bullet["rect"].left > SCREEN_WIDTH:
                player.bullets.remove(bullet)
                continue
                
            # Check enemy hits
            for enemy in enemies:
                if bullet["rect"].colliderect(enemy.rect):
                    enemy.take_damage(1)
                    if bullet in player.bullets:
                        player.bullets.remove(bullet)
                    break
        
        # Check game conditions
        if player.health <= 0:
            game_state = GAME_OVER
        elif len(enemies) == 0 and enemy_count == MAX_ENEMIES:
            game_state = VICTORY
    
    # Drawing
    screen.fill(BLACK)
    
    # Draw background (tiled if needed, without stretching)
    bg_x = camera.offset.x % bg_width - bg_width
    while bg_x < SCREEN_WIDTH:
        screen.blit(background_orig, (bg_x, 0))
        bg_x += bg_width
    
    if game_state == MENU:
        font = pygame.font.SysFont(None, 72)
        title = font.render("SIDE SCROLLER", True, WHITE)
        instruction = pygame.font.SysFont(None, 36).render("Press ENTER to Start", True, WHITE)
        screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, SCREEN_HEIGHT//3))
        screen.blit(instruction, (SCREEN_WIDTH//2 - instruction.get_width()//2, SCREEN_HEIGHT//2))
    
    elif game_state == PLAYING:
        # Draw sprites
        for sprite in all_sprites:
            screen.blit(sprite.image, (sprite.rect.x + camera.offset.x, sprite.rect.y))
        
        # Draw bullets
        for bullet in player.bullets:
            pygame.draw.rect(screen, (255, 255, 0), (
                bullet["rect"].x + camera.offset.x,
                bullet["rect"].y,
                bullet["rect"].width,
                bullet["rect"].height
            ))
        
        # Draw UI
        health_display.draw(screen)
        
        # Enemy counter
        font = pygame.font.SysFont(None, 36)
        counter = font.render(f"Enemies: {MAX_ENEMIES - len(enemies)}/{MAX_ENEMIES}", True, WHITE)
        screen.blit(counter, (SCREEN_WIDTH - 150, 10))
    
    elif game_state == GAME_OVER:
        font = pygame.font.SysFont(None, 72)
        text = font.render("GAME OVER", True, RED)
        instruction = pygame.font.SysFont(None, 36).render("Press ENTER to Restart", True, WHITE)
        screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - 50))
        screen.blit(instruction, (SCREEN_WIDTH//2 - instruction.get_width()//2, SCREEN_HEIGHT//2 + 50))
    
    elif game_state == VICTORY:
        font = pygame.font.SysFont(None, 72)
        text = font.render("VICTORY!", True, GREEN)
        instruction = pygame.font.SysFont(None, 36).render("Press ENTER to Continue", True, WHITE)
        screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - 50))
        screen.blit(instruction, (SCREEN_WIDTH//2 - instruction.get_width()//2, SCREEN_HEIGHT//2 + 50))
    
    pygame.display.flip()

pygame.quit()
sys.exit()