import pygame
import sys
import os
import random
from pygame.math import Vector2

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Screen setup
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WORLD_WIDTH = SCREEN_WIDTH * 2  # Double the screen width for the game world
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Kiyotaka")

# Game states
MENU = 0
PLAYING = 1
GAME_OVER = 2
VICTORY = 3
LEVEL_TRANSITION = 4
STORY = 5
LEVEL_INTRO = 6  # New state for level briefing
game_state = MENU

# Level settings
class Level:
    def __init__(self, number, max_enemies, enemy_speed, enemy_health, background_color, enemy_type):
        self.number = number
        self.max_enemies = max_enemies
        self.enemy_speed = enemy_speed
        self.enemy_health = enemy_health
        self.background_color = background_color
        self.completed = False
        self.enemy_type = enemy_type  # 1, 2, or 3 for different enemy types

# Define levels
LEVELS = [
    Level(1, 5, 0.8, 2, (50, 50, 50), 1),  # Level 1: Very easy - slow enemies, low health
    Level(2, 6, 1.0, 3, (30, 30, 50), 2),  # Level 2: Still easy - slightly faster, more health
    Level(3, 7, 1.2, 4, (50, 30, 30), 3)   # Level 3: Moderately easy - balanced challenge
]

current_level_index = 0
current_level = LEVELS[current_level_index]

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
GRAY = (100, 100, 100)
LIGHT_GRAY = (200, 200, 200)
DARK_BLUE = (0, 0, 30)  # Very dark blue, almost black
MEDIUM_LIGHT_BLUE = (100, 150, 255)  # New color for button text
GOLD = (255, 215, 0)  # Golden color for continue button
LIGHT_GOLD = (255, 235, 100)  # Lighter gold for hover
DARK_RED = (200, 50, 50)  # Darker red for chicken out button
LIGHT_RED = (220, 80, 80)  # Lighter dark red for hover

# Game clock
clock = pygame.time.Clock()
FPS = 60

# Physics
GRAVITY = 0.5
JUMP_STRENGTH = -12
PLAYER_SPEED = 5
GROUND_LEVEL = SCREEN_HEIGHT - 50

# Sprite scale factor
SPRITE_SCALE = 1.0  # Changed from 1.5 to 1.0 to keep original size

# Level settings
MAX_ENEMIES = 5    # Reduced from 10 to 5 for easier gameplay

# Camera class
class Camera:
    def __init__(self):
        self.x = 0
        self.width = SCREEN_WIDTH
        self.height = SCREEN_HEIGHT
        
    def update(self, target):
        # Center the camera on the player horizontally
        self.x = target.rect.centerx - self.width // 2
        
        # Keep camera within world bounds
        self.x = max(0, min(self.x, WORLD_WIDTH - self.width))
        
    def apply(self, rect):
        # Convert world coordinates to screen coordinates
        return rect.move(-self.x, 0)
        
    def apply_pos(self, pos):
        # Convert world position to screen position
        return (pos[0] - self.x, pos[1])

# Create camera instance
camera = Camera()

# Load assets
def load_spritesheet(path, frame_width, frame_height, frame_count, scale=1):
    try:
        # Convert path to use forward slashes for consistency
        path = path.replace('\\', '/')
        print(f"Attempting to load spritesheet: {path}")
        
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")
            
        # Load and verify the image
        sheet = pygame.image.load(path).convert_alpha()
        sheet_width, sheet_height = sheet.get_size()
        print(f"Loaded sheet dimensions: {sheet_width}x{sheet_height}")
        
        # Calculate actual frame count based on sheet width
        actual_frame_count = sheet_width // frame_width
        if actual_frame_count < frame_count:
            print(f"WARNING: Sheet has fewer frames than expected. Got {actual_frame_count}, need {frame_count}")
            frame_count = actual_frame_count
        
        frames = []
        for i in range(frame_count):
            x = i * frame_width
            try:
                # Extract frame directly without scaling
                frame = sheet.subsurface(pygame.Rect(x, 0, frame_width, frame_height))
                frames.append(frame)
                print(f"Successfully loaded frame {i}")
                
            except Exception as e:
                print(f"Error creating frame {i}: {str(e)}")
                # Create a placeholder frame
                placeholder = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                placeholder.fill((255, 0, 0, 255))  # Solid red
                frames.append(placeholder)
        return frames
    except Exception as e:
        print(f"Error loading spritesheet {path}: {str(e)}")
        # Return a more visible placeholder surface if loading fails
        placeholder = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
        placeholder.fill((255, 0, 0, 255))  # Solid red
        return [placeholder] * frame_count

def load_sound(path):
    return pygame.mixer.Sound(f'assets/sounds/{path}')

# Load sounds
SOUNDS = {
    'jump': load_sound('jump.wav'),
    'shoot': load_sound('shoot.wav'),
    'hit': load_sound('hit.wav'),
    'death': load_sound('death.wav'),
    'click': load_sound('click.wav')
}

# Set faster playback speed for shoot and death sounds
SOUNDS['shoot'].set_volume(0.7)  # Slightly reduce volume to compensate for faster speed
SOUNDS['death'].set_volume(0.7)  # Slightly reduce volume to compensate for faster speed

# Load UI
heart_full = pygame.image.load('assets/ui/heart_full.png').convert_alpha()
heart_empty = pygame.image.load('assets/ui/heart_empty.png').convert_alpha()

# Load menu background
try:
    menu_background = pygame.image.load('assets/ui/menu_background.png').convert()
    menu_background = pygame.transform.scale(menu_background, (SCREEN_WIDTH, SCREEN_HEIGHT))
except:
    print("Could not load menu background")
    menu_background = None

# Load cursor image
try:
    cursor_image = pygame.image.load('assets/ui/cursor.png').convert_alpha()
    pygame.mouse.set_visible(False)  # Hide system cursor
except:
    print("Could not load cursor image")
    cursor_image = None

# Load and scale background to fit world width
background = pygame.image.load('assets/background.png').convert()
background = pygame.transform.scale(background, (WORLD_WIDTH, SCREEN_HEIGHT))

# Animation class
class Animation:
    def __init__(self, frames, fps=10, loop=True):
        self.frames = frames
        self.fps = fps
        self.loop = loop
        self.frame_index = 0
        self.accumulated_time = 0
        self.done = False

    def update(self, dt):
        if self.fps <= 0: return
        self.accumulated_time += dt
        if self.accumulated_time >= 1.0 / self.fps:
            self.accumulated_time = 0
            self.frame_index += 1
            if self.frame_index >= len(self.frames):
                if self.loop: 
                    self.frame_index = 0
                else:
                    self.frame_index = len(self.frames) - 1
                    self.done = True

    def get_frame(self, flipped=False):
        frame = self.frames[int(self.frame_index)]
        if flipped:
            frame = pygame.transform.flip(frame, True, False)
        return frame

    def reset(self):
        self.frame_index = 0
        self.accumulated_time = 0
        self.done = False

# Entity class
class Entity(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, height)
        self.vel = Vector2(0, 0)
        self.facing_right = True
        self.state = "idle"
        self.animations = {}
        self.current_animation = None
        self.image = pygame.Surface((width, height), pygame.SRCALPHA)
        self.health = 5
        self.max_health = 5
        self.invincible = 0

    def load_animations(self, idle_frames, run_frames, attack_frames):
        self.animations = {
            "idle": Animation(idle_frames, fps=8),
            "run": Animation(run_frames, fps=12),
            "attack": Animation(attack_frames, fps=15, loop=False)
        }
        self.current_animation = self.animations["idle"]
        self.update_animation(0)

    def update_animation(self, dt):
        if self.state in self.animations:
            if self.current_animation != self.animations[self.state]:
                self.current_animation = self.animations[self.state]
                self.current_animation.reset()
        
        if self.current_animation:
            self.current_animation.update(dt)
            frame = self.current_animation.get_frame(not self.facing_right)
            
            # Create a new surface with the correct size and transparency
            self.image = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
            self.image.fill((0, 0, 0, 0))  # Clear the surface with full transparency
            
            # Center the frame on the surface
            frame_rect = frame.get_rect(center=(self.rect.width//2, self.rect.height//2))
            self.image.blit(frame, frame_rect)
        
        if self.invincible > 0:
            if self.invincible % 10 < 5:
                self.image.fill((255, 255, 255, 128), special_flags=pygame.BLEND_RGBA_MULT)
            self.invincible -= 1

    def take_damage(self, amount):
        if self.invincible <= 0:
            self.health -= amount
            self.invincible = 30
            return True
        return False

# Player class
class Player(Entity):
    def __init__(self, x, y):
        # Use larger size for sprites
        base_width = 128  # Increased from 64 to 128
        base_height = 128  # Increased from 64 to 128
        super().__init__(x, y, base_width, base_height)
        self.speed = PLAYER_SPEED
        self.jump_power = JUMP_STRENGTH
        self.is_jumping = False
        self.bullets = []
        self.attack_cooldown = 0
        self.health = 20
        self.max_health = 20
        self.bullet_damage = 2  # Reduced from 5 to 2
        self.rapid_fire = False
        self.rapid_fire_cooldown = 0
        self.muzzle_flash = None
        
        # Load animations with original size
        try:
            player_dir = os.path.join("assets", "player")
            print(f"Loading player animations from: {player_dir}")
            
            idle_path = os.path.join(player_dir, "idle.png")
            run_path = os.path.join(player_dir, "run.png")
            attack_path = os.path.join(player_dir, "attack.png")
            
            print(f"Loading idle animation from: {idle_path}")
            idle_frames = load_spritesheet(idle_path, base_width, base_height, 4)
            
            print(f"Loading run animation from: {run_path}")
            run_frames = load_spritesheet(run_path, base_width, base_height, 6)
            
            print(f"Loading attack animation from: {attack_path}")
            attack_frames = load_spritesheet(attack_path, base_width, base_height, 4)
            
            self.load_animations(idle_frames, run_frames, attack_frames)
            print("Successfully loaded all player animations")
        except Exception as e:
            print(f"Error loading player animations: {str(e)}")
            placeholder = pygame.Surface((base_width, base_height), pygame.SRCALPHA)
            placeholder.fill((0, 255, 0, 255))
            self.load_animations([placeholder]*4, [placeholder]*6, [placeholder]*4)

    def update(self, dt):
        # Physics
        self.vel.y += GRAVITY
        self.rect.x += self.vel.x
        self.rect.y += self.vel.y
        
        # Ground collision
        if self.rect.bottom >= GROUND_LEVEL:
            self.rect.bottom = GROUND_LEVEL
            self.vel.y = 0
            self.is_jumping = False
        
        # Get keyboard input
        keys = pygame.key.get_pressed()
        move_x = keys[pygame.K_d] - keys[pygame.K_a]
        self.vel.x = move_x * self.speed
        
        # Update facing direction
        if move_x != 0:
            self.facing_right = move_x > 0
        
        # Handle rapid fire
        if keys[pygame.K_SPACE]:
            if not self.rapid_fire:
                self.rapid_fire = True
                self.shoot()  # Initial shot
            elif self.rapid_fire_cooldown <= 0:
                self.shoot()  # Continuous fire
                self.rapid_fire_cooldown = 3  # Very short cooldown for rapid fire
        else:
            self.rapid_fire = False
        
        # Update cooldowns
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        if self.rapid_fire_cooldown > 0:
            self.rapid_fire_cooldown -= 1
        
        # State management
        new_state = "idle"
        if self.state == "attack" and not self.current_animation.done:
            new_state = "attack"
        elif abs(self.vel.x) > 0.1:
            new_state = "run"
        
        if new_state != self.state:
            self.state = new_state
        
        # Update animation
        self.update_animation(dt)

    def jump(self):
        if not self.is_jumping:
            self.vel.y = self.jump_power
            self.is_jumping = True
            SOUNDS['jump'].play()

    def shoot(self):
        if self.attack_cooldown == 0:
            self.state = "attack"
            self.attack_cooldown = 5
            SOUNDS['shoot'].play()  # Volume is already set
            
            # Create muzzle flash
            flash_x = self.rect.right if self.facing_right else self.rect.left
            flash_y = self.rect.centery
            self.muzzle_flash = MuzzleFlash((flash_x, flash_y), 1 if self.facing_right else -1)
            
            # Create bullet with trail
            bullet = {
                "rect": pygame.Rect(
                    self.rect.right if self.facing_right else self.rect.left - 8,
                    self.rect.centery - 2,
                    8,
                    4
                ),
                "direction": 1 if self.facing_right else -1,
                "speed": 15,
                "damage": self.bullet_damage,
                "trail": BulletTrail(
                    (self.rect.right if self.facing_right else self.rect.left, 
                     self.rect.centery),
                    1 if self.facing_right else -1
                )
            }
            self.bullets.append(bullet)

# Enemy class
class Enemy(Entity):
    def __init__(self, x, y, enemy_type=1):
        # Use larger size for sprites
        base_width = 128  # Increased from 64 to 128
        base_height = 128  # Increased from 64 to 128
        super().__init__(x, y, base_width, base_height)
        self.speed = current_level.enemy_speed
        self.attack_cooldown = 0
        self.health = current_level.enemy_health
        self.max_health = current_level.enemy_health
        self.enemy_type = enemy_type  # Store enemy type
        
        # Patrol settings
        self.patrol_start_x = x  # Starting position for patrol
        self.patrol_distance = 200  # How far to patrol in each direction
        self.patrol_direction = 1  # 1 for right, -1 for left
        self.patrol_speed = 1.5  # Slower speed for patrolling
        
        # Add attack sequence tracking
        self.attack_sequence = 1  # Start with attack_1
        self.attack_sequence_timer = 0
        self.attack_sequence_delay = 30  # Frames between attack sequences
        
        # Load animations with larger size
        try:
            enemy_dir = os.path.join("assets", "enemy")
            print(f"\nLoading enemy type {enemy_type} animations from: {enemy_dir}")
            
            # Use numbered sprite paths based on enemy type
            idle_path = os.path.join(enemy_dir, f"idle_{enemy_type}.png")
            walk_path = os.path.join(enemy_dir, f"walk_{enemy_type}.png")
            run_path = os.path.join(enemy_dir, f"run_{enemy_type}.png")
            attack1_path = os.path.join(enemy_dir, f"attack_1_{enemy_type}.png")
            attack2_path = os.path.join(enemy_dir, f"attack_2_{enemy_type}.png")
            attack3_path = os.path.join(enemy_dir, f"attack_3_{enemy_type}.png")
            hurt_path = os.path.join(enemy_dir, f"hurt_{enemy_type}.png")
            dead_path = os.path.join(enemy_dir, "dead.png")  # Shared death animation
            
            print(f"Loading idle animation from: {idle_path}")
            print(f"Loading walk animation from: {walk_path}")
            print(f"Loading run animation from: {run_path}")
            print(f"Loading attack animations from: {attack1_path}, {attack2_path}, {attack3_path}")
            print(f"Loading hurt animation from: {hurt_path}")
            print(f"Loading death animation from: {dead_path}")
            
            # Load all animations with correct frame counts
            idle_frames = load_spritesheet(idle_path, base_width, base_height, 4)
            walk_frames = load_spritesheet(walk_path, base_width, base_height, 11)
            run_frames = load_spritesheet(run_path, base_width, base_height, 9)
            attack1_frames = load_spritesheet(attack1_path, base_width, base_height, 6)
            attack2_frames = load_spritesheet(attack2_path, base_width, base_height, 4)
            attack3_frames = load_spritesheet(attack3_path, base_width, base_height, 5)
            hurt_frames = load_spritesheet(hurt_path, base_width, base_height, 2)
            dead_frames = load_spritesheet(dead_path, base_width, base_height, 4)
            
            print(f"Successfully loaded animations:")
            print(f"- idle frames: {len(idle_frames)}")
            print(f"- walk frames: {len(walk_frames)}")
            print(f"- run frames: {len(run_frames)}")
            print(f"- attack1 frames: {len(attack1_frames)}")
            print(f"- attack2 frames: {len(attack2_frames)}")
            print(f"- attack3 frames: {len(attack3_frames)}")
            print(f"- hurt frames: {len(hurt_frames)}")
            print(f"- death frames: {len(dead_frames)}")
            
            # Update animations dictionary with all new animations
            self.animations = {
                "idle": Animation(idle_frames, fps=8),
                "walk": Animation(walk_frames, fps=12),
                "run": Animation(run_frames, fps=15),
                "attack_1": Animation(attack1_frames, fps=15, loop=False),
                "attack_2": Animation(attack2_frames, fps=15, loop=False),
                "attack_3": Animation(attack3_frames, fps=15, loop=False),
                "hurt": Animation(hurt_frames, fps=8, loop=False),
                "dead": Animation(dead_frames, fps=8, loop=True)  # Death animation loops
            }
            self.current_animation = self.animations["idle"]
            
        except Exception as e:
            print(f"Error loading enemy animations: {str(e)}")
            print("Creating placeholder animations...")
            placeholder = pygame.Surface((base_width, base_height), pygame.SRCALPHA)
            placeholder.fill((255, 0, 0, 255))
            self.load_animations([placeholder]*4, [placeholder]*6, [placeholder]*4)

    def take_damage(self, amount):
        if self.invincible <= 0:
            self.health -= amount
            
            # Spawn blood particles
            for _ in range(20):  # More blood particles
                # Spawn around the enemy's center
                offset_x = random.randint(-self.rect.width//2, self.rect.width//2)
                offset_y = random.randint(-self.rect.height//2, self.rect.height//2)
                blood_particles.append(BloodParticle(
                    self.rect.centerx + offset_x,
                    self.rect.centery + offset_y
                ))
            
            # Add blood splashes
            for _ in range(5):  # Add some bigger blood splashes
                offset_x = random.randint(-self.rect.width//2, self.rect.width//2)
                offset_y = random.randint(-self.rect.height//2, self.rect.height//2)
                blood_particles.append(BloodParticle(
                    self.rect.centerx + offset_x,
                    self.rect.centery + offset_y,
                    is_splash=True
                ))
            
            self.invincible = 30
            if self.health <= 0:
                # Extra blood when enemy dies
                for _ in range(30):  # Even more blood on death
                    offset_x = random.randint(-self.rect.width, self.rect.width)
                    offset_y = random.randint(-self.rect.height, self.rect.height)
                    blood_particles.append(BloodParticle(
                        self.rect.centerx + offset_x,
                        self.rect.centery + offset_y,
                        is_splash=random.random() < 0.3  # 30% chance of being a splash
                    ))
                SOUNDS['death'].play()
                self.kill()
            else:
                self.state = "hurt"
                self.current_animation = self.animations["hurt"]
                self.current_animation.reset()
            return True
        return False

    def update(self, player, dt):
        # AI behavior
        dx = player.rect.centerx - self.rect.centerx
        distance = abs(dx)
        
        # State machine
        if self.invincible > 0:
            self.vel.x = 0
            if self.state != "hurt":
                self.state = "hurt"
                self.current_animation = self.animations["hurt"]
                self.current_animation.reset()
        elif distance < 50:  # Attack range
            self.vel.x = 0
            self.facing_right = dx > 0
            
            # Handle attack sequence
            if self.attack_sequence_timer <= 0:
                if self.attack_sequence == 1:
                    self.state = "attack_1"
                    if self.current_animation.done and self.attack_cooldown == 0:
                        if self.rect.colliderect(player.rect):
                            player.take_damage(1)
                            SOUNDS['hit'].play()
                        self.attack_sequence = 2
                        self.attack_sequence_timer = self.attack_sequence_delay
                        self.attack_cooldown = 60
                elif self.attack_sequence == 2:
                    self.state = "attack_2"
                    if self.current_animation.done:
                        self.attack_sequence = 3
                        self.attack_sequence_timer = self.attack_sequence_delay
                elif self.attack_sequence == 3:
                    self.state = "attack_3"
                    if self.current_animation.done:
                        self.attack_sequence = 1
                        self.attack_sequence_timer = self.attack_sequence_delay
            else:
                self.attack_sequence_timer -= 1
                
        elif distance < 300:  # Detection range
            self.state = "run"
            self.vel.x = (1 if dx > 0 else -1) * self.speed
            self.facing_right = dx > 0
            self.attack_sequence = 1  # Reset attack sequence when not attacking
        else:
            # Patrol behavior
            self.state = "walk"
            self.vel.x = self.patrol_direction * self.patrol_speed
            self.facing_right = self.patrol_direction > 0
            self.attack_sequence = 1  # Reset attack sequence when not attacking
            
            # Check if we've reached patrol boundaries
            if self.rect.centerx >= self.patrol_start_x + self.patrol_distance:
                self.patrol_direction = -1
            elif self.rect.centerx <= self.patrol_start_x - self.patrol_distance:
                self.patrol_direction = 1
        
        # Movement
        self.rect.x += self.vel.x
        self.rect.y = GROUND_LEVEL - self.rect.height
        
        # Update animation
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1
        self.update_animation(dt)

# Health display
class HealthDisplay:
    def __init__(self, player):
        self.player = player
        self.width = 200
        self.height = 20
        self.border = 2
        self.position = (10, 10)
    
    def draw(self, surface):
        # Draw background (empty health)
        pygame.draw.rect(surface, (50, 50, 50), 
                        (self.position[0], self.position[1], 
                         self.width, self.height))
        
        # Draw health bar
        health_width = (self.width - 2 * self.border) * (self.player.health / self.player.max_health)
        health_rect = (self.position[0] + self.border, 
                      self.position[1] + self.border,
                      health_width, 
                      self.height - 2 * self.border)
        
        # Create gradient effect
        for i in range(int(health_width)):
            alpha = int(255 * (1 - i/health_width * 0.3))  # Slight fade to the right
            color = (255 - i/health_width * 100,  # Red component decreases
                    50 + i/health_width * 100,    # Green component increases
                    50)                           # Blue stays constant
            pygame.draw.line(surface, color,
                           (self.position[0] + self.border + i, self.position[1] + self.border),
                           (self.position[0] + self.border + i, self.position[1] + self.height - self.border))
        
        # Draw border
        pygame.draw.rect(surface, (100, 100, 100), 
                        (self.position[0], self.position[1], 
                         self.width, self.height), 
                        self.border)
        
        # Draw health text
        font = pygame.font.SysFont(None, 16)
        health_text = font.render(f"{self.player.health}/{self.player.max_health}", True, (200, 200, 200))
        text_rect = health_text.get_rect(center=(self.position[0] + self.width//2, 
                                               self.position[1] + self.height//2))
        surface.blit(health_text, text_rect)

# Load fonts
try:
    # Try to load Bangers font
    title_font = pygame.font.Font('assets/fonts/Bangers-Regular.ttf', 90)  # Larger size for title
except:
    print("Could not load Bangers font, using system font")
    title_font = pygame.font.SysFont(None, 90)

# Button class
class Button:
    def __init__(self, x, y, width, height, text, color, hover_color, is_chat_skip=False):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.current_color = color
        # Use smaller font for chat skip button
        if is_chat_skip:
            self.font = pygame.font.SysFont(None, 16)  # Smaller font for chat skip
        else:
            self.font = pygame.font.SysFont(None, 32)  # Normal font for other buttons
        self.radius = 10
        # Create highlight surface
        self.highlight = pygame.Surface((width, height), pygame.SRCALPHA)
        # Draw gradient highlight
        for i in range(height//2):
            alpha = int(255 * (1 - i/(height//2)))
            pygame.draw.line(self.highlight, (255, 255, 255, alpha), 
                           (0, i), (width, i))
        
    def draw(self, surface):
        # Draw base rounded rectangle
        pygame.draw.rect(surface, self.current_color, self.rect, border_radius=self.radius)
        
        # Draw shiny highlight
        highlight_rect = self.highlight.get_rect(topleft=self.rect.topleft)
        surface.blit(self.highlight, highlight_rect, special_flags=pygame.BLEND_RGBA_ADD)
        
        # Draw text with shadow
        text_surface = self.font.render(self.text, True, DARK_BLUE)
        text_rect = text_surface.get_rect(center=self.rect.center)
        # Draw text shadow
        shadow_surface = self.font.render(self.text, True, (0, 0, 0, 128))
        shadow_rect = shadow_surface.get_rect(center=(text_rect.centerx + 1, text_rect.centery + 1))
        surface.blit(shadow_surface, shadow_rect)
        surface.blit(text_surface, text_rect)
        
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.current_color = self.hover_color if self.rect.collidepoint(event.pos) else self.color
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                SOUNDS['click'].play()
                return True
        return False

# Create menu buttons
play_button = Button(SCREEN_WIDTH//2 - 75, SCREEN_HEIGHT//2 - 75, 150, 40, "Play", GRAY, LIGHT_GRAY)
donate_button = Button(SCREEN_WIDTH//2 - 75, SCREEN_HEIGHT//2, 150, 40, "Donate", GRAY, LIGHT_GRAY)
exit_button = Button(SCREEN_WIDTH//2 - 75, SCREEN_HEIGHT//2 + 75, 150, 40, "Exit", GRAY, LIGHT_GRAY)

# Load menu music
try:
    pygame.mixer.music.load('assets/sounds/menu_music.mp3')
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(0)  # 0 means play once, -1 would mean loop indefinitely
except:
    print("Could not load menu music")

# Load story music
try:
    story_music = pygame.mixer.Sound('assets/sounds/story_music.mp3')
    story_music.set_volume(0.5)
except:
    print("Could not load story music")
    story_music = None

# Story text
STORY_TEXT = [
    "In a world overrun by darkness,",
    "Kiyotaka stands as the last hope.",
    "",
    "Armed with courage and determination,",
    "he must face the forces of evil",
    "and restore light to the land.",
    "",
    "Will you help Kiyotaka",
    "in his quest for victory?"
]

# Story screen variables
story_y_offset = SCREEN_HEIGHT  # Start below the screen
story_speed = 50  # Pixels per second
story_done = False

# Level briefing text
LEVEL_BRIEFINGS = [
    [
        "Sgt. Jeff: Private Kiyotaka, we've got a situation.",
        "Sgt. Jeff: Dark mages have started summoning werewolves.",
        "Sgt. Jeff: They're fast but fragile. Use your agility.",
        "Sgt. Jeff: Show them what you're made of, soldier!"
    ],
    [
        "Sgt. Jeff: The mages are getting desperate, Private.",
        "Sgt. Jeff: Their werewolves are stronger now.",
        "Sgt. Jeff: But I know you can handle it.",
        "Sgt. Jeff: Time to step up your game!"
    ],
    [
        "Sgt. Jeff: This is it, Private Kiyotaka.",
        "Sgt. Jeff: The final ritual is complete.",
        "Sgt. Jeff: The strongest werewolves are here.",
        "Sgt. Jeff: Make me proud, soldier!"
    ]
]

# Chat bubble settings
CHAT_FONT_SIZE = 16
CHAT_LINE_HEIGHT = 20
CHAT_BUBBLE_PADDING = 10
CHAT_BUBBLE_MARGIN = 5
CHAT_BUBBLE_COLOR = (40, 40, 40)
CHAT_TEXT_COLOR = (200, 200, 200)
CHAT_NAME_COLOR = (100, 150, 255)
TYPEWRITER_SPEED = 0.02
CHAT_DELAY = 4.0  # Increased from 2.0 to 4.0 seconds
FADE_SPEED = 2  # Decreased from 5 to 2 for slower fades

# Chat bubble class
class ChatBubble:
    def __init__(self, text):
        self.text = text
        self.current_text = ""
        self.last_update = 0
        self.done = False
        self.font = pygame.font.SysFont(None, CHAT_FONT_SIZE)
        self.alpha = 0  # Start fully transparent
        self.fade_in = True
        self.fade_out = False
        
    def update(self, dt):
        if self.fade_in:
            self.alpha = min(255, self.alpha + FADE_SPEED)
            if self.alpha == 255:
                self.fade_in = False
        
        if not self.done and not self.fade_in:
            self.last_update += dt
            if self.last_update >= TYPEWRITER_SPEED:
                self.last_update = 0
                if len(self.current_text) < len(self.text):
                    self.current_text = self.text[:len(self.current_text) + 1]
                else:
                    self.done = True
        
        if self.fade_out:
            self.alpha = max(0, self.alpha - FADE_SPEED)
    
    def draw(self, surface):
        # Split name and message
        name, message = self.text.split(": ", 1)
        current_message = self.current_text.split(": ", 1)[1] if ": " in self.current_text else ""
        
        # Render name and message
        name_surface = self.font.render(name + ": ", True, CHAT_NAME_COLOR)
        message_surface = self.font.render(current_message, True, CHAT_TEXT_COLOR)
        
        # Calculate bubble size
        bubble_width = max(name_surface.get_width() + message_surface.get_width() + CHAT_BUBBLE_PADDING * 2, 150)
        bubble_height = CHAT_LINE_HEIGHT + CHAT_BUBBLE_PADDING * 2
        
        # Create bubble surface
        bubble = pygame.Surface((bubble_width, bubble_height), pygame.SRCALPHA)
        bubble.fill((0, 0, 0, 0))
        
        # Draw bubble background with current alpha
        bubble_color = (*CHAT_BUBBLE_COLOR, self.alpha)
        pygame.draw.rect(bubble, bubble_color, (0, 0, bubble_width, bubble_height), border_radius=5)
        
        # Draw text with current alpha
        name_surface.set_alpha(self.alpha)
        message_surface.set_alpha(self.alpha)
        bubble.blit(name_surface, (CHAT_BUBBLE_PADDING, CHAT_BUBBLE_PADDING))
        bubble.blit(message_surface, (CHAT_BUBBLE_PADDING + name_surface.get_width(), CHAT_BUBBLE_PADDING))
        
        # Position bubble at top center
        x = (SCREEN_WIDTH - bubble_width) // 2
        y = 20
        surface.blit(bubble, (x, y))

# Create chat skip button
chat_skip_button = Button(20, SCREEN_HEIGHT - 40, 60, 20, "Skip", GRAY, LIGHT_GRAY, is_chat_skip=True)

# Level intro variables
current_chat_index = 0
chat_bubbles = []
chat_timer = 0

def handle_chat_skip():
    global current_chat_index, chat_timer
    if current_chat_index < len(chat_bubbles):
        # Skip current message
        current_bubble = chat_bubbles[current_chat_index]
        current_bubble.done = True
        current_bubble.current_text = current_bubble.text
        current_bubble.alpha = 0  # Force fade out
        current_bubble.fade_out = True
        
        # Move to next message
        current_chat_index += 1
        chat_timer = 0
        
        # Initialize next message if exists
        if current_chat_index < len(chat_bubbles):
            next_bubble = chat_bubbles[current_chat_index]
            next_bubble.done = True
            next_bubble.current_text = next_bubble.text
            next_bubble.alpha = 255
            next_bubble.fade_in = False

# Game initialization
def init_game():
    global player, all_sprites, enemies, health_display, enemy_count, current_chat_index, chat_bubbles, chat_timer
    
    # Reset chat variables
    current_chat_index = 0
    chat_bubbles = []
    chat_timer = 0
    
    # Create groups
    all_sprites = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    
    # Create player at the left side of the screen
    player = Player(100, GROUND_LEVEL - 64)  # Start at x=100 (left side)
    all_sprites.add(player)
    health_display = HealthDisplay(player)
    
    # Create enemies in pairs
    enemy_count = current_level.max_enemies
    for i in range(0, min(4, current_level.max_enemies), 2):  # Spawn in pairs, max 2 pairs initially
        # First enemy of the pair
        x1 = random.randint(SCREEN_WIDTH // 2, SCREEN_WIDTH - 200)
        enemy1 = Enemy(x1, GROUND_LEVEL - 64, current_level.enemy_type)  # Pass enemy type from current level
        enemies.add(enemy1)
        all_sprites.add(enemy1)
        
        # Second enemy of the pair, slightly offset from the first
        x2 = x1 + random.randint(50, 150)  # Place second enemy 50-150 pixels to the right of first
        enemy2 = Enemy(x2, GROUND_LEVEL - 64, current_level.enemy_type)  # Pass enemy type from current level
        enemies.add(enemy2)
        all_sprites.add(enemy2)
    
    # Initialize chat bubbles for the current level
    chat_bubbles = []
    for line in LEVEL_BRIEFINGS[current_level_index]:
        chat_bubbles.append(ChatBubble(line))
    if chat_bubbles:
        chat_bubbles[0].update(0)

# Add new color constants
BULLET_COLOR = (255, 200, 0)  # Brighter yellow for bullets
MUZZLE_FLASH_COLOR = (255, 255, 200)  # Bright white-yellow for muzzle flash

# Add bullet trail class
class BulletTrail:
    def __init__(self, start_pos, direction):
        self.particles = []
        self.direction = direction
        self.lifetime = 10  # Frames to live
        self.create_trail(start_pos)
        
    def create_trail(self, start_pos):
        # Create initial trail particles
        for i in range(5):
            offset = -i * 3 * self.direction  # Space particles behind bullet
            self.particles.append({
                'pos': (start_pos[0] + offset, start_pos[1]),
                'size': max(1, 3 - i),  # Decreasing size
                'alpha': 255 - i * 50  # Decreasing opacity
            })
    
    def update(self):
        # Update particle positions and fade out
        for particle in self.particles:
            particle['alpha'] = max(0, particle['alpha'] - 25)
            particle['size'] = max(0.5, particle['size'] - 0.2)
        self.lifetime -= 1
    
    def draw(self, surface, camera):
        for particle in self.particles:
            if particle['alpha'] > 0:
                pos = camera.apply_pos(particle['pos'])
                size = particle['size']
                color = (*BULLET_COLOR[:3], int(particle['alpha']))
                pygame.draw.circle(surface, color, (int(pos[0]), int(pos[1])), int(size))

# Add muzzle flash class
class MuzzleFlash:
    def __init__(self, pos, direction):
        self.pos = pos
        self.direction = direction
        self.lifetime = 3  # Very short lifetime
        self.size = 15
        self.alpha = 255
        
    def update(self):
        self.lifetime -= 1
        self.size = max(0, self.size - 5)
        self.alpha = max(0, self.alpha - 85)
        
    def draw(self, surface, camera):
        if self.lifetime > 0:
            pos = camera.apply_pos(self.pos)
            color = (*MUZZLE_FLASH_COLOR[:3], int(self.alpha))
            pygame.draw.circle(surface, color, (int(pos[0]), int(pos[1])), int(self.size))

# Create fade surface
fade_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
fade_surface.fill(BLACK)
fade_alpha = 0
fade_speed = 5  # Speed of fade effect

# Create game over buttons
restart_button = Button(SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2 - 20, 140, 40, "Restart", GRAY, LIGHT_GRAY)
home_button = Button(SCREEN_WIDTH//2 + 10, SCREEN_HEIGHT//2 - 20, 140, 40, "Home", GRAY, LIGHT_GRAY)

# Create story screen buttons
continue_button = Button(SCREEN_WIDTH//2 - 75, SCREEN_HEIGHT//2, 150, 40, "Continue", GOLD, LIGHT_GOLD)
chicken_out_button = Button(SCREEN_WIDTH//2 - 75, SCREEN_HEIGHT//2 + 60, 150, 40, "Chicken Out", DARK_RED, LIGHT_RED)
skip_button = Button(20, SCREEN_HEIGHT - 50, 80, 30, "Skip", GRAY, LIGHT_GRAY)

# Create victory screen buttons
victory_restart_button = Button(SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2 + 20, 140, 40, "Restart", GRAY, LIGHT_GRAY)
victory_home_button = Button(SCREEN_WIDTH//2 + 10, SCREEN_HEIGHT//2 + 20, 140, 40, "Home", GRAY, LIGHT_GRAY)
victory_continue_button = Button(SCREEN_WIDTH//2 - 70, SCREEN_HEIGHT//2 + 80, 140, 40, "Continue", GRAY, LIGHT_GRAY)

# Add blood particle class
class BloodParticle:
    def __init__(self, x, y, is_splash=False):
        self.x = x
        self.y = y
        self.is_splash = is_splash
        if is_splash:
            self.size = random.randint(8, 15)  # Bigger for splashes
            self.lifetime = random.randint(40, 60)  # Longer lasting splashes
            self.vel_x = random.uniform(-5, 5)
            self.vel_y = random.uniform(-8, -3)  # Higher upward velocity
            self.gravity = 0.15  # Slower gravity for splashes
            self.color = (random.randint(180, 220), 0, 0)  # Brighter red for splashes
        else:
            self.size = random.randint(3, 8)  # Bigger droplets
            self.lifetime = random.randint(30, 50)  # Longer lasting droplets
            self.vel_x = random.uniform(-4, 4)
            self.vel_y = random.uniform(-6, -2)  # Higher upward velocity
            self.gravity = 0.2
            self.color = (random.randint(150, 200), 0, 0)  # Dark red
        
    def update(self):
        self.vel_y += self.gravity
        self.x += self.vel_x
        self.y += self.vel_y
        self.lifetime -= 1
        if self.is_splash:
            self.size = max(0, self.size - 0.15)  # Slower shrinking for splashes
        else:
            self.size = max(0, self.size - 0.1)
        
    def draw(self, surface, camera):
        if self.lifetime > 0:
            pos = camera.apply_pos((int(self.x), int(self.y)))
            if self.is_splash:
                # Draw a more complex blood splash
                pygame.draw.circle(surface, self.color, pos, int(self.size))
                # Add some variation to make it look more like a splash
                for _ in range(3):
                    offset_x = random.randint(-2, 2)
                    offset_y = random.randint(-2, 2)
                    pygame.draw.circle(surface, self.color, 
                                     (pos[0] + offset_x, pos[1] + offset_y), 
                                     int(self.size * 0.7))
            else:
                pygame.draw.circle(surface, self.color, pos, int(self.size))

# Add blood particles list to the game
blood_particles = []

# Main game loop
running = True

while running:
    dt = clock.tick(FPS) / 1000.0
    
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if game_state == PLAYING:
                    game_state = MENU
                    pygame.mixer.music.play(0)  # Play once when returning to menu
                else:
                    running = False
            elif event.key == pygame.K_RETURN:
                if game_state == MENU:
                    game_state = STORY
                    story_y_offset = SCREEN_HEIGHT
                    story_done = False
                    if story_music:
                        story_music.play(0)
                elif game_state == LEVEL_TRANSITION:
                    current_level_index += 1
                    current_level = LEVELS[current_level_index]
                    game_state = LEVEL_INTRO
                    # Initialize chat for new level
                    current_chat_index = 0
                    chat_bubbles = []
                    chat_timer = 0
                elif game_state == LEVEL_INTRO:
                    if current_chat_index >= len(chat_bubbles) and all(bubble.done for bubble in chat_bubbles):
                        init_game()
                        game_state = PLAYING
                    elif game_state in [GAME_OVER, VICTORY]:
                        current_level_index = 0
                        current_level = LEVELS[current_level_index]
                        game_state = LEVEL_INTRO
                        # Initialize chat for first level
                        current_chat_index = 0
                        chat_bubbles = []
                        chat_timer = 0
            elif game_state == PLAYING:
                if event.key == pygame.K_w:
                    player.jump()
        
        # Handle menu button clicks
        if game_state == MENU:
            if play_button.handle_event(event):
                game_state = STORY
                story_y_offset = SCREEN_HEIGHT
                story_done = False
                if story_music:
                    story_music.play(0)
            elif donate_button.handle_event(event):
                # Open donate link in browser
                import webbrowser
                webbrowser.open('https://your-donate-link.com')
            elif exit_button.handle_event(event):
                running = False
        
        # Handle story screen button clicks
        elif game_state == STORY:
            # Draw dark background
            screen.fill((20, 20, 30))  # Dark blue-black background
            
            # Update story scroll position
            if not story_done:
                story_y_offset -= story_speed * dt
                # Calculate total text height
                total_height = len(STORY_TEXT) * 40
                if story_y_offset < -total_height:
                    story_done = True
                    story_y_offset = -total_height
            
            # Draw story text
            font = pygame.font.SysFont(None, 36)
            y_offset = story_y_offset
            for line in STORY_TEXT:
                text = font.render(line, True, WHITE)
                text_rect = text.get_rect(center=(SCREEN_WIDTH//2, y_offset))
                screen.blit(text, text_rect)
                y_offset += 40
            
            # Show skip button while story is scrolling
            if not story_done:
                skip_button.draw(screen)
            
            # Show main buttons when story is done
            if story_done:
                continue_button.draw(screen)
                chicken_out_button.draw(screen)
            
            # Handle story screen button clicks
            if continue_button.handle_event(event) and story_done:
                current_level_index = 0  # Reset to level 1
                current_level = LEVELS[current_level_index]
                init_game()  # Initialize game with chat bubbles
                game_state = LEVEL_INTRO  # Go directly to level intro
                pygame.mixer.music.stop()  # Stop menu music when playing
                if story_music:
                    story_music.stop()  # Stop story music
            elif chicken_out_button.handle_event(event) and story_done:
                game_state = MENU
                pygame.mixer.music.play(0)  # Play menu music again
                if story_music:
                    story_music.stop()  # Stop story music
            elif skip_button.handle_event(event) and not story_done:
                story_done = True
                story_y_offset = -len(STORY_TEXT) * 40  # Jump to final position
        
        # Handle chat skip button clicks
        elif game_state == LEVEL_INTRO:
            if event.type == pygame.MOUSEBUTTONDOWN and chat_skip_button.rect.collidepoint(event.pos):
                handle_chat_skip()
        
        # Handle game over button clicks
        elif game_state == GAME_OVER:
            if restart_button.handle_event(event):
                current_level_index = 0
                current_level = LEVELS[current_level_index]
                init_game()
                game_state = PLAYING
                fade_alpha = 0  # Reset fade
            elif home_button.handle_event(event):
                game_state = MENU
                fade_alpha = 0  # Reset fade
        
        # Handle victory screen button clicks
        elif game_state == VICTORY:
            if victory_restart_button.handle_event(event):
                current_level_index = 0
                current_level = LEVELS[current_level_index]
                init_game()
                game_state = PLAYING
            elif victory_home_button.handle_event(event):
                game_state = MENU
                pygame.mixer.music.play(0)  # Play menu music again
            elif victory_continue_button.handle_event(event):
                if current_level_index < len(LEVELS) - 1:
                    current_level_index += 1
                    current_level = LEVELS[current_level_index]
                    game_state = LEVEL_INTRO
                    # Initialize chat for new level
                    current_chat_index = 0
                    chat_bubbles = []
                    chat_timer = 0
                else:
                    # If it's the last level, go back to menu
                    game_state = MENU
                    pygame.mixer.music.play(0)  # Play menu music again
    
    # Game logic
    if game_state == PLAYING:
        # Player movement
        keys = pygame.key.get_pressed()
        player.vel.x = (keys[pygame.K_d] - keys[pygame.K_a]) * player.speed
        
        # Keep player within world bounds
        player.rect.clamp_ip(pygame.Rect(0, 0, WORLD_WIDTH, SCREEN_HEIGHT))
        
        # Update objects
        player.update(dt)
        
        # Update camera
        camera.update(player)
        
        # Spawn enemies in pairs
        if len(enemies) < enemy_count and random.random() < 0.02:
            # Find a good position for the first enemy
            x1 = random.randint(SCREEN_WIDTH // 2, WORLD_WIDTH - 200)
            enemy1 = Enemy(x1, GROUND_LEVEL - 64, current_level.enemy_type)  # Pass enemy type from current level
            enemies.add(enemy1)
            all_sprites.add(enemy1)
            
            # Spawn second enemy of the pair
            if len(enemies) < enemy_count:  # Check if we can spawn the second enemy
                x2 = x1 + random.randint(50, 150)  # Place second enemy 50-150 pixels to the right of first
                enemy2 = Enemy(x2, GROUND_LEVEL - 64, current_level.enemy_type)  # Pass enemy type from current level
                enemies.add(enemy2)
                all_sprites.add(enemy2)
        
        # Update enemies
        for enemy in list(enemies):
            enemy.update(player, dt)
            if enemy.health <= 0:
                enemies.remove(enemy)
                all_sprites.remove(enemy)
        
        # Update bullets
        for bullet in list(player.bullets):
            # Draw trail
            bullet["trail"].draw(screen, camera)
            bullet["trail"].update()
            
            # Draw bullet
            bullet_rect = bullet["rect"].copy()
            screen_pos = camera.apply(bullet_rect)
            pygame.draw.ellipse(screen, BULLET_COLOR, screen_pos)  # Draw as ellipse instead of rectangle
            
            # Update bullet position
            bullet["rect"].x += bullet["direction"] * bullet["speed"]
                
            # Check enemy hits
            for enemy in enemies:
                if bullet["rect"].colliderect(enemy.rect):
                    enemy.take_damage(bullet["damage"])  # Use bullet's damage property
                    if bullet in player.bullets:
                        player.bullets.remove(bullet)
                    break
        
        # Check game conditions
        if player.health <= 0:
            game_state = GAME_OVER
            fade_alpha = 0  # Start fade from 0
        elif len(enemies) == 0 and enemy_count == current_level.max_enemies:
            current_level.completed = True
            game_state = VICTORY  # Show victory screen after completing any level
    
    # Drawing
    screen.fill(current_level.background_color if game_state not in [MENU, STORY] else BLACK)
    
    if game_state == MENU:
        # Draw menu background
        if menu_background:
            screen.blit(menu_background, (0, 0))
        else:
            screen.blit(background, (0, 0))  # Fallback to game background
        
        # Draw title with enhanced shadow
        title = title_font.render("KIYOTAKA", True, RED)
        title_shadow = title_font.render("KIYOTAKA", True, (50, 0, 0))  # Darker red for shadow
        title_rect = title.get_rect(center=(SCREEN_WIDTH//2, 100))  # Fixed position near top
        # Draw multiple shadow layers for depth
        for offset in range(5, 0, -1):
            screen.blit(title_shadow, (title_rect.x + offset, title_rect.y + offset))
        screen.blit(title, title_rect)
        
        # Draw buttons
        play_button.draw(screen)
        donate_button.draw(screen)
        exit_button.draw(screen)
    
    elif game_state == STORY:
        # Draw dark background
        screen.fill((20, 20, 30))  # Dark blue-black background
        
        # Update story scroll position
        if not story_done:
            story_y_offset -= story_speed * dt
            # Calculate total text height
            total_height = len(STORY_TEXT) * 40
            if story_y_offset < -total_height:
                story_done = True
                story_y_offset = -total_height
        
        # Draw story text
        font = pygame.font.SysFont(None, 36)
        y_offset = story_y_offset
        for line in STORY_TEXT:
            text = font.render(line, True, WHITE)
            text_rect = text.get_rect(center=(SCREEN_WIDTH//2, y_offset))
            screen.blit(text, text_rect)
            y_offset += 40
        
        # Show skip button while story is scrolling
        if not story_done:
            skip_button.draw(screen)
        
        # Show main buttons when story is done
        if story_done:
            continue_button.draw(screen)
            chicken_out_button.draw(screen)
    
    elif game_state == PLAYING:
        # Draw background with camera offset
        screen.blit(background, (-camera.x, 0))
        
        # Draw sprites with camera offset
        for sprite in all_sprites:
            screen.blit(sprite.image, camera.apply(sprite.rect))
        
        # Draw muzzle flash if active
        if player.muzzle_flash:
            player.muzzle_flash.draw(screen, camera)
            player.muzzle_flash.update()
            if player.muzzle_flash.lifetime <= 0:
                player.muzzle_flash = None
        
        # Draw bullets with trails
        for bullet in player.bullets:
            # Draw trail
            bullet["trail"].draw(screen, camera)
            bullet["trail"].update()
            
            # Draw bullet
            bullet_rect = bullet["rect"].copy()
            screen_pos = camera.apply(bullet_rect)
            pygame.draw.ellipse(screen, BULLET_COLOR, screen_pos)  # Draw as ellipse instead of rectangle
            
            # Update bullet position
            bullet["rect"].x += bullet["direction"] * bullet["speed"]
            
            # Remove if off-screen
            if bullet["rect"].right < 0 or bullet["rect"].left > WORLD_WIDTH:
                player.bullets.remove(bullet)
                continue
        
        # Draw UI (no camera offset needed)
        health_display.draw(screen)
        
        # Enemy counter
        font = pygame.font.SysFont(None, 24)
        counter = font.render(f"Enemies: {MAX_ENEMIES - len(enemies)}/{MAX_ENEMIES}", True, RED)
        screen.blit(counter, (SCREEN_WIDTH - 150, 10))
        
        # Level display
        level_text = font.render(f"Level: {current_level.number}", True, WHITE)
        screen.blit(level_text, (10, 30))
    
    elif game_state == GAME_OVER:
        # Draw the game screen first
        screen.blit(background, (-camera.x, 0))
        for sprite in all_sprites:
            screen.blit(sprite.image, camera.apply(sprite.rect))
        
        # Apply fade effect
        fade_alpha = min(200, fade_alpha + fade_speed)  # Cap at 200 for semi-transparency
        fade_surface.set_alpha(fade_alpha)
        screen.blit(fade_surface, (0, 0))
        
        # Draw game over text
        font = pygame.font.SysFont(None, 72)
        text = font.render("GAME OVER", True, RED)
        text_rect = text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 100))
        screen.blit(text, text_rect)
        
        # Draw buttons
        restart_button.draw(screen)
        home_button.draw(screen)
    
    elif game_state == VICTORY:
        # Draw the game screen first
        screen.blit(background, (-camera.x, 0))
        for sprite in all_sprites:
            screen.blit(sprite.image, camera.apply(sprite.rect))
        
        # Draw victory text
        font = pygame.font.SysFont(None, 72)
        text = font.render("VICTORY!", True, GREEN)
        text_rect = text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 - 100))
        screen.blit(text, text_rect)
        
        # Draw basic buttons without shiny effect
        pygame.draw.rect(screen, GRAY, victory_restart_button.rect, border_radius=10)
        pygame.draw.rect(screen, GRAY, victory_home_button.rect, border_radius=10)
        pygame.draw.rect(screen, GRAY, victory_continue_button.rect, border_radius=10)
        
        # Draw button text
        restart_text = victory_restart_button.font.render(victory_restart_button.text, True, DARK_BLUE)
        home_text = victory_home_button.font.render(victory_home_button.text, True, DARK_BLUE)
        continue_text = victory_continue_button.font.render(victory_continue_button.text, True, DARK_BLUE)
        
        screen.blit(restart_text, restart_text.get_rect(center=victory_restart_button.rect.center))
        screen.blit(home_text, home_text.get_rect(center=victory_home_button.rect.center))
        screen.blit(continue_text, continue_text.get_rect(center=victory_continue_button.rect.center))
    
    elif game_state == LEVEL_TRANSITION:
        font = pygame.font.SysFont(None, 72)
        text = font.render(f"Level {current_level.number} Complete!", True, GREEN)
        instruction = pygame.font.SysFont(None, 36).render("Press ENTER to Continue", True, WHITE)
        screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - 50))
        screen.blit(instruction, (SCREEN_WIDTH//2 - instruction.get_width()//2, SCREEN_HEIGHT//2 + 50))
    
    elif game_state == LEVEL_INTRO:
        # Draw the game background
        screen.blit(background, (-camera.x, 0))
        
        # Initialize chat bubbles if needed
        if not chat_bubbles:
            chat_bubbles = []
            # Create one bubble for each message
            for line in LEVEL_BRIEFINGS[current_level_index]:
                chat_bubbles.append(ChatBubble(line))
            
            # Start first message immediately
            current_chat_index = 0
            chat_timer = 0
            if chat_bubbles:
                chat_bubbles[0].update(0)
        
        # Update and draw current chat bubble
        chat_timer += dt
        if current_chat_index < len(chat_bubbles):
            current_bubble = chat_bubbles[current_chat_index]
            current_bubble.update(dt)
            
            # Check if current message is done and time to move to next
            if current_bubble.done and chat_timer >= CHAT_DELAY:
                current_bubble.fade_out = True
                if current_bubble.alpha <= 0:
                    current_chat_index += 1
                    chat_timer = 0
                    if current_chat_index < len(chat_bubbles):
                        chat_bubbles[current_chat_index].update(0)
        
        # Draw current chat bubble
        if current_chat_index < len(chat_bubbles):
            chat_bubbles[current_chat_index].draw(screen)
            # Show skip button while chat is active
            chat_skip_button.draw(screen)
            
            # Handle skip button click
            if chat_skip_button.handle_event(event):
                handle_chat_skip()
        
        # Check if all chats are done
        if current_chat_index >= len(chat_bubbles) and all(bubble.done for bubble in chat_bubbles):
            # Draw press enter prompt
            prompt_font = pygame.font.SysFont(None, 24)
            prompt = prompt_font.render("Press ENTER to begin your battle...", True, (200, 200, 200))
            prompt_rect = prompt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2))  # Center of screen
            screen.blit(prompt, prompt_rect)
        
        # Draw player (standing still)
        if hasattr(player, 'image'):
            screen.blit(player.image, camera.apply(player.rect))

    # Draw custom cursor
    if cursor_image:
        mouse_pos = pygame.mouse.get_pos()
        screen.blit(cursor_image, mouse_pos)
    
    # Update blood particles
    for particle in blood_particles[:]:
        particle.update()
        if particle.lifetime <= 0:
            blood_particles.remove(particle)
    
    # Draw blood particles
    for particle in blood_particles:
        particle.draw(screen, camera)
    
    pygame.display.flip()

pygame.quit()
sys.exit()