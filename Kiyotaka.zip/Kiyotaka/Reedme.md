Hi there!

This was meant to be  a simple coding project to test my understanding with programming.
The game is free, i call it a project not an actual game.

/////////////////////////////////////////////////////////////////////
Instructions;
use A and S keys for movement
W to Jump and SPACEBAR to shoot


************************************************
Have fun! and happy customization :)

2025 AD


- CyberGhost 

